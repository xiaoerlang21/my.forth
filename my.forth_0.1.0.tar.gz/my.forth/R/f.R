#' Title
#'
#' @param x safasfd
#'
#' @return asdfasdf
#' @export
#'
#' @examples x=1;f(x)
f<-function(x){return(x+1)}
